/********************************************************************************************************
 * Refer to this link for a detailed explaination of parallelized version of quicksort  				*
 * http://parallelcomp.uw.hu/ch09lev1sec4.html 															*
 * 																										*
 * Refer to this link for more info on parsing xml using C++ library									*
 * http://www.dinomage.com/2012/01/tutorial-using-tinyxml-part-1 										*
 * 																										*
 * For executing using the thread support, you'll need to compile using c++11 standard  				*
 * and link it against the pthread library. Also, for using tinyXML library, we need to 				*
 * compile all the modules from tinyXML and include "tinyxml.h".										*
 *																										*
 * So the command becomes for compilation becomes huge-													*
 * g++ quick_sort.c++ tinystr.cpp tinyxml.cpp tinyxmlparser.cpp tinyxmlerror.cpp -pthread -std=c++11 	*
 *																										*
 * To run-																								*
 * ./a.out																								*
 ********************************************************************************************************/

#include <iostream>
#include <stdio.h>
#include <thread>
#include "tinyxml.h"


using namespace std;

class quick_sort
{

	public:
		static void quickSort(int [], int, int);
		static void printArr(int [], int);
		
};

/* A[] --> Array to be sorted, l  --> Starting index, h  --> Ending index */
void quick_sort::quickSort(int arr[], int l, int h)
{
    if (l < h)
    {        
        int x = arr[h];
    	int i = (l - 1);
		int t;
    	for (int j = l; j <= h- 1; j++)
    	{
    	    if (arr[j] <= x)
    	    {
    	        i++;
    	        t=arr[i];
    	        arr[i]=arr[j];
    	        arr[j]=t;
    	    }
    	}
    	t=arr[i + 1];
    	arr[i + 1]=arr[h];
        arr[h]=t;
        
        int p = i+1;
        
        thread first (quickSort, arr, l, p - 1);  
        thread second (quickSort, arr, p + 1, h);
        /*Un-comment the next two lines to examine the thread ID's*/
        //cout<<"First thread ID: "<<first.get_id()<<"\n";
        //cout<<"Second thread ID: "<<second.get_id()<<"\n";
        first.join();
        second.join();
    }
}


void quick_sort::printArr( int arr[], int n )
{
    int i;
    for ( i = 0; i < n; ++i )
        cout<<arr[i]<<" ";
	cout<<"\n";
}

// Driver program to test above functions
int main()
{
	
    int arr[20], n=0;
    /* We're loading all the data from xml file into the object of type TiXmlDocument. "doc" holds all the data 
     * We also check if ther is an error in loading the xml file.
     */
    TiXmlDocument doc;
	if(!doc.LoadFile("elements_qs.xml"))
	{
	    cerr << doc.ErrorDesc() << endl;
	    cout<<"Error in openeing xml file";
	    return -1;
	}
	
	/*Get the root element.
	 * The FirstChildElement() method returns a TiXmlElement pointer to the first child node.
	 */
	TiXmlElement* root = doc.FirstChildElement();
	if(root == NULL)
	{
	    cerr << "Failed to load file: No root element."
	         << endl;
	    doc.Clear();
	    cout<<"Error in accessing root child\n";
	    return -1;
	}
	
	
	/*Iterate over the elements in the xml file and store them in the array */
	for (TiXmlElement* elem = root->FirstChildElement(); elem != NULL; elem = elem->NextSiblingElement())
		arr[n++]=atoi(elem->GetText());
   
    quick_sort q;
    q.quickSort( arr, 0, n - 1 );
    q.printArr( arr, n );
    return 0;
}
