#include<iostream>
using namespace std;
class q{
	 public:
		int p,q;
		void quicksort(int [10],int p,int q);
		int partition(int [10],int p,int q);
	};

void q::quicksort(int *x,int p,int q)
{
	int r;
	if(p<q)
	{
	   r=this->partition(x,p,q);
	
	   #pragma omp parallel sections
	   {
		#pragma omp section
		   quicksort(x,p,r);
		#pragma omp section
		   quicksort(x,(r+1),q);
	   }
	}
}
int q::partition(int ar[],int left,int right)
{
	int pivot=ar[left];
	#pragma omp parallel num_threads(2)
	{
	   while(left!=right)
	   {
		if(ar[left]>ar[right])
		   swap(ar[left],ar[right]);
		if(pivot==ar[left])
		   right--;
		else
		   left++;
	   }
	}
	return left;	
}
int main()
{
	int x[10],size,i;
	q obj;
	cout<<"\n enter size-";
	cin>>size;
	cout<<"\n enter elements-";
	for(i=0;i<size;i++)
	{
		cin>>x[i];
	}
	obj.quicksort(x,0,size-1);
	cout<<"\n sorted array-";
	for(i=0;i<size;i++)
	{
		cout<<"\t"<<x[i];
	}
	return 0;
}
